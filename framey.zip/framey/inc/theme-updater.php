<?php

/**
 * UiCore Theme Updater & Plugin Installer
 *
 * @package uicore-theme
 */
defined('ABSPATH') || exit;

// Store connection token (optional use)
update_option('uicore_connect', [
    'url' => home_url(),
    'token' => '50372973ui119'
]);

// Define the version info JSON URL from GitHub
define('WPRISE_FRAMEY_JSON', 'https://raw.githubusercontent.com/wprise/ftheme/main/version_info.json');

/**
 * Utility: Get download URL from version_info.json
 */
function wprise_get_git_urls($json_url, $item_key = 'theme') {
    $response = wp_remote_get($json_url);

    if (is_wp_error($response)) {
        return false;
    }

    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);

    if ($item_key === 'theme' && isset($data['download_url'])) {
        return $data['download_url'];
    }

    if (isset($data['plugins'][$item_key])) {
        return $data['plugins'][$item_key];
    }

    return false;
}

if (wp_get_theme('framey')->exists()) {

    /**
     * Theme update check
     */
    add_filter('pre_set_site_transient_update_themes', function ($transient) {
        if (empty($transient->checked)) {
            return $transient;
        }

        $theme = wp_get_theme('framey');
        $current_version = $theme->Version;

        $response = wp_remote_get(WPRISE_FRAMEY_JSON);

        if (is_wp_error($response) || wp_remote_retrieve_response_code($response) !== 200) {
            return $transient;
        }

        $data = json_decode(wp_remote_retrieve_body($response), true);

        if ($data && version_compare($current_version, $data['version'], '<')) {
            $transient->response['framey'] = [
                'theme'       => 'framey',
                'new_version' => $data['version'],
                'url'         => $data['info_url'],
                'package'     => wprise_get_git_urls(WPRISE_FRAMEY_JSON, 'theme'),
            ];
        }

        return $transient;
    });

    /**
     * Install bundled plugins from the theme folder (as before)
     */
    function wprise_install_bundled_plugins() {
        $theme_plugin_dir = get_template_directory() . '/inc/plugins/';
        $zips = [
            'uicore-framework.zip'       => 'uicore-framework',
            'bdthemes-element-pack.zip'  => 'bdthemes-element-pack'
        ];

        include_once ABSPATH . 'wp-admin/includes/file.php';
        include_once ABSPATH . 'wp-admin/includes/misc.php';
        include_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';

        WP_Filesystem();
        global $wp_filesystem;

        foreach ($zips as $zip_file => $plugin_slug) {
            $zip_path = $theme_plugin_dir . $zip_file;
            $plugin_path = WP_PLUGIN_DIR . '/' . $plugin_slug;

            // Delete existing plugin folder
            if (is_dir($plugin_path)) {
                $wp_filesystem->delete($plugin_path, true);
            }

            // Unzip new version
            if (file_exists($zip_path)) {
                unzip_file($zip_path, WP_PLUGIN_DIR);
            }
        }
    }

    /**
     * After theme update, trigger plugin install/update
     */
    add_action('upgrader_process_complete', function ($upgrader, $hook_extra) {
        if (
            isset($hook_extra['type'], $hook_extra['action']) &&
            $hook_extra['type'] === 'theme' &&
            $hook_extra['action'] === 'update' &&
            !empty($hook_extra['themes']) &&
            in_array('framey', $hook_extra['themes'], true)
        ) {
            wprise_install_bundled_plugins();
        }
    }, 10, 2);

    /**
     * Hide "Updates" menu item in admin
     */
    add_action('admin_footer', function () {
        ?>
        <script type="text/javascript">
            jQuery(document).ready(function ($) {
                setTimeout(function () {
                    $('.uicore-core-menu li:has(a[href="#/updates"])').remove();
                }, 1000);
            });
        </script>
        <?php
    });
}